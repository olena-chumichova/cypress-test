Тo run the tests you need:
1. Open cupress 
2. Find test_Michael_Jordan
3. Run it

If you wont to run it from PS using terminal:
1. Write in terminal npx cypress run
Еhe test will pass and you will get the results