import GooglePage from '../../pages/google_page';
import SearchPage from '../../pages/search_page';

describe('Michael Jordan Test', () => {

  const googlePage = new GooglePage();
  const searchPage = new SearchPage();

    it('Visits the google', () => {
      cy.visit('https://www.google.com')
    })

    it('Test results', ()=> {
    const searchItem = 'Michael Jordan'
    googlePage.getSearchTextBox(searchItem);

    searchPage.getResultsLinks(searchItem);
    })
  })