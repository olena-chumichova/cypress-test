class GooglePage {
    getSearchTextBox(searchItem) {
        return cy.get('[name=q]').type(`${searchItem}{enter}`);
    }
    }
    export default GooglePage