class SearchPage {
    getResultsLinks(searchResult) {
        return cy.get('div.yuRUbf > a > h3').each(($el) =>
        cy.wrap($el).should('contain.text', searchResult))
    }
}
export default SearchPage
